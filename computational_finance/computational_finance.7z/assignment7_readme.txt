METHOD:
Sample size = 100000
Monthly path for 1 year maturity, n_steps = 12
For each sample, iterate from 1 to 12 (12 months). 
- In each step, calculate the local volatility in (t - (t-1)) by CEV, similar approaching as assignment5.
- Calculate the stock price and firm value in each month
Calculate the forward rate of each month by LIBOR rate model, store in an array. Select the 1 year forward rate from the array
Use it forward rate to find the discount factor => use it to price the up-and-out call option
Calculate the cva, similar to assignment3


CODE STRUCTURE:
Main code run in assignment7.py
assignment7.py call function discount_factor_libor in assignment7_interest_rate.py to find discount factor
Separate discount factor to another file to keep code clean,and easier to add code to calibrate forward rate later


PENDING:
- Estimate firm value using Merton model. At the moment, select firm value = 200 (acceptable by Sergio in Assignment5)
- Calibrate the forward rate base on the provide bond price list



